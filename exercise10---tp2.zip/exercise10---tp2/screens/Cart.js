import React from 'react';
import { View, Text, StyleSheet, FlatList, Button } from 'react-native';
import CartItem from '../components/CartItem';

const Cart = ({ cart, navigation }) => {
  const totalPrice = cart.reduce((total, item) => total + item.price, 0);

  return (
    <View style={styles.container}>
      <FlatList
        data={cart}
        renderItem={({ item }) => <CartItem product={item} />}
        keyExtractor={(item) => item.id}
      />
      <Text style={styles.total}>Total: R$ {totalPrice.toFixed(2)}</Text>
      <Button title="Voltar para a lista de produtos" onPress={() => navigation.goBack()} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 20,
    backgroundColor: '#f8f8f8',
  },
  total: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginVertical: 15,
  },
});

export default Cart;
