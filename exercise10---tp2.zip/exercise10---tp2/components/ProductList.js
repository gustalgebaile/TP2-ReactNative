import React from 'react';
import { FlatList, StyleSheet, View, Button } from 'react-native';
import ProductItem from './ProductItem';

const ProductList = ({ addToCart, navigation }) => {
  const products = [
    { id: '1', name: 'Produto 1', price: 29.99 },
    { id: '2', name: 'Produto 2', price: 49.99 },
    { id: '3', name: 'Produto 3', price: 19.99 },
    { id: '4', name: 'Produto 4', price: 39.99 },
  ];

  return (
    <View style={styles.container}>
      <FlatList
        data={products}
        renderItem={({ item }) => <ProductItem product={item} addToCart={addToCart} />}
        keyExtractor={(item) => item.id}
      />
      <Button title="Ir para o carrinho" onPress={() => navigation.navigate('Cart')} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 20,
    backgroundColor: '#f8f8f8',
  },
});

export default ProductList;
