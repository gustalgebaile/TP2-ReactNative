import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Carousel from './components/Carrossel';

export default function App() {
  const items = ['Item 1', 'Item 2', 'Item 3', 'Item 4', 'Item 5'];

  return (
    <SafeAreaView style={styles.container}>
      <Carousel items={items} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f2f2f2',
  },
});
