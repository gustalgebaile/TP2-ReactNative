import React from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import CarouselItem from './CarrosselItem';

const Carrossel = ({ items }) => {
  return (
    <View style={styles.carousel}>
      <FlatList
        data={items}
        renderItem={({ item }) => <CarouselItem text={item} />}
        keyExtractor={(item, index) => index.toString()}
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.listContent}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  carousel: {
    height: 100,
  },
  listContent: {
    alignItems: 'center',
    paddingHorizontal: 10,
  },
});

export default Carrossel;
