import React from 'react';
import { View, StyleSheet } from 'react-native';
import GridItem from './GridItem';

const Grid = ({ items }) => {
  return (
    <View style={styles.gridContainer}>
      {items.map((item, index) => (
        <GridItem key={index} text={item} />
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    margin: 10,
  },
});

export default Grid;
