import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import Grid from './components/Grid';

export default function App() {
  const items = [
    'Item 1',
    'Item 2',
    'Item 3',
    'Item 4',
    'Item 5',
    'Item 6',
    'Item 7',
    'Item 8',
  ];

  return (
    <SafeAreaView style={styles.container}>
      <Grid items={items} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f8f8f8',
  },
});
