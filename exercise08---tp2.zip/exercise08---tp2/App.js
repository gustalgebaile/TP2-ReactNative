import React from 'react';
import { SafeAreaView, StyleSheet, FlatList } from 'react-native';
import ContactList from './components/ContactList';

export default function App() {
  const contacts = [
    { id: '1', name: 'Pablo Vegetti', address: 'Avenida Roberto Dinamite 10, Rio de Janeiro, Brasil', phone: '(21) 91998-2000', avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3Q8ltyU4P0f1HfxkxS-c9_en_65x2zUbm1-Hhn5CxMPI4znaPWuFLdKflNso8XCfccEc&usqp=CAU' },
    { id: '2', name: 'Mohamed Salah', address: 'Anfield Rd, Anfield, Liverpool L4 0TH, Reino Unido', phone: '+44 151 264 2500', avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTG43CzRADA_GjiFQ9wNfmSzfmnE-_Vl9F0TKHLhNafT4f_aAF66Iezl_yzydbshZ1mD6M&usqp=CAU' },
    { id: '3', name: 'Kelly Slater', address: '18556 Jackson Ave, Lemoore, CA 93245, Estados Unidos', phone: '+1 951 11992-2011', avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTdhjdKeA61JZLKkTuXoiXpy-A2_aOyDjR3VA&s' },
  ];

  return (
    <SafeAreaView style={styles.container}>
      <ContactList contacts={contacts} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
});
