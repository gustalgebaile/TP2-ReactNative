import React from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import ContactItem from './ContactItem';

const ContactList = ({ contacts }) => {
  return (
    <FlatList
      data={contacts}
      renderItem={({ item }) => <ContactItem contact={item} />}
      keyExtractor={(item) => item.id}
    />
  );
};

const styles = StyleSheet.create({
  listContainer: {
    paddingTop: 20,
  },
});

export default ContactList;
