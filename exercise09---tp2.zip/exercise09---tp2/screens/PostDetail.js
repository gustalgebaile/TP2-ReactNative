import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const PostDetail = ({ route }) => {
  const { postId } = route.params;

  const posts = [
    { id: '1', title: 'Postagem 1', summary: 'Resumo da postagem 1', likes: 120, shares: 30, content: 'Detalhes completos da postagem 1.' },
    { id: '2', title: 'Postagem 2', summary: 'Resumo da postagem 2', likes: 90, shares: 20, content: 'Detalhes completos da postagem 2.' },
    { id: '3', title: 'Postagem 3', summary: 'Resumo da postagem 3', likes: 150, shares: 40, content: 'Detalhes completos da postagem 3.' },
  ];

  const post = posts.find((post) => post.id === postId);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{post.title}</Text>
      <Text style={styles.content}>{post.content}</Text>
      <Text style={styles.likes}>Curtidas: {post.likes}</Text>
      <Text style={styles.shares}>Compartilhamentos: {post.shares}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f8f8f8',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  content: {
    fontSize: 16,
    color: '#666',
    marginVertical: 15,
  },
  likes: {
    fontSize: 14,
    color: '#333',
  },
  shares: {
    fontSize: 14,
    color: '#333',
  },
});

export default PostDetail;
