import React from 'react';
import { FlatList, StyleSheet, View } from 'react-native';
import PostItem from './PostItem';

const PostList = ({ navigation }) => {
  const posts = [
    { id: '1', title: 'Postagem 1', summary: 'Resumo da postagem 1', likes: 120, shares: 30 },
    { id: '2', title: 'Postagem 2', summary: 'Resumo da postagem 2', likes: 90, shares: 20 },
    { id: '3', title: 'Postagem 3', summary: 'Resumo da postagem 3', likes: 150, shares: 40 },
  ];

  return (
    <FlatList
      data={posts}
      renderItem={({ item }) => (
        <PostItem
          post={item}
          onPress={() => navigation.navigate('PostDetail', { postId: item.id })}
        />
      )}
      keyExtractor={(item) => item.id}
    />
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 20,
    backgroundColor: '#f8f8f8',
  },
});

export default PostList;
