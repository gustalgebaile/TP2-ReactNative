import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

const PostItem = ({ post, onPress }) => {
  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      <View style={styles.content}>
        <Text style={styles.title}>{post.title}</Text>
        <Text style={styles.summary}>{post.summary}</Text>
        <View style={styles.stats}>
          <Text style={styles.stat}>Curtidas: {post.likes}</Text>
          <Text style={styles.stat}>Compartilhamentos: {post.shares}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff',
    padding: 15,
    marginBottom: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  content: {
    flexDirection: 'column',
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  summary: {
    fontSize: 14,
    color: '#666',
    marginVertical: 5,
  },
  stats: {
    marginTop: 10,
  },
  stat: {
    fontSize: 12,
    color: '#333',
  },
});

export default PostItem;
