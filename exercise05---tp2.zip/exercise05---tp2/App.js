import React from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import List from './components/List';

export default function App() {
  const items = ['Tarefa 1', 'Tarefa 2', 'Tarefa 3', 'Tarefa 4'];

  return (
    <SafeAreaView style={styles.container}>
      <List items={items} />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'flex-start',
    backgroundColor: '#f8f8f8',
    paddingHorizontal: 20,
  },
});
