import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const AcademicInfo = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Informações Acadêmicas</Text>
      <Text>Graduação: Engenharia de Software - Instituto Infnet (2023-2027)</Text>
      <Text>Graduação: Ciências Contábeis - Universidade Federal do Rio de Janeiro (2023-2024)</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
});

export default AcademicInfo;
