import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import PersonalInfo from './screens/PersonalInfo';
import AcademicInfo from './screens/AcademicInfo';
import ExperienceInfo from './screens/ExperienceInfo';
import LanguagesInfo from './screens/LanguagesInfo';

const Drawer = createDrawerNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Pessoal">
        <Drawer.Screen name="Pessoal" component={PersonalInfo} />
        <Drawer.Screen name="Acadêmico" component={AcademicInfo} />
        <Drawer.Screen name="Experiência" component={ExperienceInfo} />
        <Drawer.Screen name="Idiomas" component={LanguagesInfo} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
