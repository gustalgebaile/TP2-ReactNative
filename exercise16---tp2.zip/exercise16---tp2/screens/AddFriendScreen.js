import React, { useState } from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';

export default function AddFriendScreen() {
  const [friends, setFriends] = useState([
    { id: '1', name: 'Amigo Novo 1', added: false },
    { id: '2', name: 'Amigo Novo 2', added: false },
    { id: '3', name: 'Amigo Novo 3', added: false },
  ]);

  const addFriend = (id) => {
    setFriends((prevFriends) =>
      prevFriends.map((friend) =>
        friend.id === id ? { ...friend, added: true } : friend
      )
    );
  };

  return (
    <FlatList
      data={friends}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <View style={styles.friendContainer}>
          <Text style={styles.friendName}>{item.name}</Text>
          <Button
            title={item.added ? 'Adicionado' : 'Adicionar'}
            onPress={() => addFriend(item.id)}
            disabled={item.added}
          />
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  friendContainer: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  friendName: {
    fontSize: 18,
  },
});
