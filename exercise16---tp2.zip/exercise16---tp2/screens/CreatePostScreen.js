import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

export default function CreatePostScreen({ navigation, route }) {
  const [postContent, setPostContent] = useState('');

  const handlePost = () => {
    if (postContent.trim()) {
      route.params.addPost(postContent);
      setPostContent('');
      navigation.navigate('Feed');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Nova Postagem</Text>
      <TextInput
        style={styles.input}
        placeholder="Escreva sua postagem..."
        value={postContent}
        onChangeText={setPostContent}
        multiline
      />
      <Button title="Publicar" onPress={handlePost} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    height: 100,
    borderColor: '#ccc',
    borderWidth: 1,
    marginBottom: 10,
    padding: 10,
  },
});
