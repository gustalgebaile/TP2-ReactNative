import React from 'react';
import { View, Text, Button, FlatList, StyleSheet } from 'react-native';

export default function FeedScreen({ navigation, posts }) {
  return (
    <FlatList
      data={posts}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <View style={styles.postContainer}>
          <Text style={styles.author}>Autor: {item.author}</Text>
          <Text style={styles.content}>{item.content}</Text>
          <View style={styles.buttonContainer}>
            <Button title={item.liked ? 'Curtido' : 'Curtir'} onPress={() => {}} />
            <Button
              title="Ver Detalhes"
              onPress={() => navigation.navigate('PostDetail', { post: item })}
            />
          </View>
        </View>
      )}
    />
  );
}

const styles = StyleSheet.create({
  postContainer: {
    padding: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#ccc',
  },
  author: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  content: {
    fontSize: 14,
    marginVertical: 5,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
});
