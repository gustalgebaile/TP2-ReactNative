import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function MyPostsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Minhas Postagens</Text>
      <Text>O VASCO GANHOU!!!</Text>
      <Text>777 é o demônio</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
});
