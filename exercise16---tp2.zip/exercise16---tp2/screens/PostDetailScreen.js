import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function PostDetailScreen({ route }) {
  // Obtemos os detalhes da postagem através das propriedades passadas na navegação
  const { post } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Detalhes da Postagem</Text>
      <Text style={styles.author}>Autor: {post.author}</Text>
      <Text style={styles.content}>{post.content}</Text>
      <Text style={styles.date}>Data: {post.date}</Text> {/* Exemplo de detalhe adicional */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  author: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  content: {
    fontSize: 16,
    marginVertical: 10,
  },
  date: {
    fontSize: 14,
    color: 'gray',
  },
});
