import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import FeedScreen from './screens/FeedScreen';
import ProfileScreen from './screens/ProfileScreen';
import MyPostsScreen from './screens/MyPostsScreen';
import FriendsScreen from './screens/FriendsScreen';
import SettingsScreen from './screens/SettingsScreen';
import CreatePostScreen from './screens/CreatePostScreen';
import PostDetailScreen from './screens/PostDetailScreen';

const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();

function FeedStack({ posts }) {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Feed" options={{ headerShown: false }}>
        {(props) => <FeedScreen {...props} posts={posts} />}
      </Stack.Screen>
      <Stack.Screen name="PostDetail" component={PostDetailScreen} options={{ title: 'Detalhes da Postagem' }} />
    </Stack.Navigator>
  );
}

export default function App() {
  const [posts, setPosts] = useState([
    { id: '1', author: 'Gabriel G.', content: 'Olá, essa é minha primeira postagem!', liked: false, date: '2024-11-15' },
    { id: '2', author: 'Antonio M.', content: 'Curtindo o dia de hoje!', liked: false, date: '2024-11-14' },
  ]);

  const addPost = (content) => {
    const newPost = { id: Date.now().toString(), author: 'Usuário', content, liked: false, date: new Date().toLocaleDateString() };
    setPosts((prevPosts) => [newPost, ...prevPosts]);
  };

  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Feed">
        <Drawer.Screen name="Feed">
          {(props) => <FeedStack {...props} posts={posts} />}
        </Drawer.Screen>
        <Drawer.Screen name="Novo Post">
          {(props) => <CreatePostScreen {...props} addPost={addPost} />}
        </Drawer.Screen>
        <Drawer.Screen name="Perfil" component={ProfileScreen} />
        <Drawer.Screen name="Minhas Postagens" component={MyPostsScreen} />
        <Drawer.Screen name="Amigos" component={FriendsScreen} />
        <Drawer.Screen name="Configurações" component={SettingsScreen} />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}
