import React from 'react';
import { View, Button, Text, StyleSheet } from 'react-native';

const ItemCard = ({ item, onLike }) => {
  return (
    <View style={styles.cardContainer}>
      <Text style={styles.itemTitle}>{item.name}</Text>
      <View style={styles.buttonContainer}>
        <Button title="Gostei" onPress={() => onLike(true)} />
        <View style={styles.spacing} />
        <Button title="Não gostei" onPress={() => onLike(false)} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  cardContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  itemTitle: {
    fontSize: 24,
    marginBottom: 20,
  },
  buttonContainer: {
    width: '100%',
    alignItems: 'center',
  },
  spacing: {
    height: 15,
  },
});

export default ItemCard;
