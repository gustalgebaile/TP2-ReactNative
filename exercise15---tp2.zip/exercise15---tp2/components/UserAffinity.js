import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const UserAffinity = ({ user }) => {
  return (
    <View style={styles.userContainer}>
      <Text style={styles.userName}>{user.name}</Text>
      <Text>Afinação: {user.affinity.toFixed(2)}%</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  userContainer: {
    marginBottom: 15,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default UserAffinity;
