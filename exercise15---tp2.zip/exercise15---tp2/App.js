import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { View, Text, Button, StyleSheet, ScrollView } from 'react-native';
import ItemCard from './components/ItemCard';
import UserAffinity from './components/UserAffinity';

const Stack = createStackNavigator();

const itemsList = [
  { id: 1, name: 'Inception' },
  { id: 2, name: 'The Dark Knight' },
  { id: 3, name: 'Interstellar' },
  { id: 4, name: 'Avengers: Endgame' },
  { id: 5, name: 'The Matrix' },
  { id: 6, name: 'Spider-Man: No Way Home' },
  { id: 7, name: 'Titanic' },
  { id: 8, name: 'The Lion King' },
  { id: 9, name: 'Frozen' },
  { id: 10, name: 'Star Wars: The Force Awakens' },
];

const users = [
  { id: 1, name: 'User 1', likedItems: [1, 3, 5, 8] },
  { id: 2, name: 'User 2', likedItems: [2, 3, 4, 6] },
  { id: 3, name: 'User 3', likedItems: [1, 2, 7, 9] },
  { id: 4, name: 'User 4', likedItems: [5, 7, 10] },
  { id: 5, name: 'User 5', likedItems: [6, 8, 10] },
];

function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Button
        title="Começar a avaliar filmes"
        onPress={() => navigation.navigate('Items')}
      />
    </View>
  );
}

function ItemsScreen({ navigation }) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [userLikes, setUserLikes] = useState([]);

  const handleLike = (liked) => {
    setUserLikes([...userLikes, { item: itemsList[currentIndex].id, liked }]);
    const nextIndex = currentIndex + 1;
    if (nextIndex < itemsList.length) {
      setCurrentIndex(nextIndex);
    } else {
      navigation.navigate('Affinity', { userLikes });
    }
  };

  const item = itemsList[currentIndex];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.itemTitle}>{item.name}</Text>
      <View style={styles.buttonContainer}>
        <Button title="Gostei" onPress={() => handleLike(true)} />
        <View style={styles.spacing} />
        <Button title="Não gostei" onPress={() => handleLike(false)} />
      </View>
    </ScrollView>
  );
}

function AffinityScreen({ route }) {
  const { userLikes } = route.params;

  const calculateAffinity = (likedItems) => {
    return users.map((user) => {
      const commonLikes = user.likedItems.filter(item => likedItems.includes(item)).length;
      const affinity = (commonLikes / likedItems.length) * 100;
      return { ...user, affinity };
    }).sort((a, b) => b.affinity - a.affinity);
  };

  const affinityUsers = calculateAffinity(userLikes.map(like => like.item));

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Usuários com gostos semelhantes</Text>
      {affinityUsers.map((user, index) => (
        <UserAffinity key={user.id} user={user} />
      ))}
    </ScrollView>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Items" component={ItemsScreen} />
        <Stack.Screen name="Affinity" component={AffinityScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  itemTitle: {
    fontSize: 24,
    marginBottom: 20,
  },
  buttonContainer: {
    width: '100%',
    alignItems: 'center',
  },
  spacing: {
    height: 15,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
});
