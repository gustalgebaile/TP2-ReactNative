import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const CategoriesScreen = ({ navigation }) => {
  const categories = ['Mercado', 'Farmácia', 'Estudos'];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Categorias de Tarefas</Text>
      {categories.map((category, index) => (
        <View style={styles.buttonContainer} key={index}>
          <Button
            title={category}
            onPress={() => navigation.navigate('Tarefas', { category })}
          />
        </View>
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  buttonContainer: {
    marginBottom: 15,
    width: '100%',
  },
});

export default CategoriesScreen;
