// App.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import CategoriesScreen from './screens/CategoriesScreen';
import TasksScreen from './screens/TasksScreen';

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Categorias">
        <Stack.Screen name="Categorias" component={CategoriesScreen} />
        <Stack.Screen name="Tarefas" component={TasksScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
