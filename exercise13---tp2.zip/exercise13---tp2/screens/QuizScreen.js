import React, { useState } from 'react';
import { View, Text, Button, StyleSheet, ScrollView } from 'react-native';

const questions = [
  {
    question: "Qual é a capital do Brasil?",
    options: ["Rio de Janeiro", "São Paulo", "Brasília", "Salvador"],
    correctAnswer: "Brasília",
  },
  {
    question: "Qual é a língua oficial dos EUA?",
    options: ["Inglês", "Espanhol", "Francês", "Alemão"],
    correctAnswer: "Inglês",
  },
  {
    question: "Quem pintou a Mona Lisa?",
    options: ["Vincent van Gogh", "Pablo Picasso", "Leonardo da Vinci", "Michelangelo"],
    correctAnswer: "Leonardo da Vinci",
  },
  {
    question: "Qual é o capitão do Vasco?",
    options: ["Vegetti", "Payet", "Maicon", "Hugo Moura"],
    correctAnswer: "Vegetti",
  },
  {
    question: "Quando foi o segunda guerra mundial?",
    options: ["1936-1944", "1940-1946", "1934-1939", "1939-1945"],
    correctAnswer: "1939-1945",
  },
  {
    question: "Qual é o pai da computação?",
    options: ["Steve Jobs", "Alan Turing", "Tim Berners-Lee", "Bill Gates"],
    correctAnswer: "Alan Turing",
  },
  {
    question: "Quem é maior surfista de todos os tempos?",
    options: ["Andy Irons", "Gabriel Medina", "Kelly Slater", "Tom Curren"],
    correctAnswer: "Kelly Slater",
  },
  {
    question: "Qual o maior império em tamanho contíguo?",
    options: ["Império Romano", "Império Britânico", "Império Mongol", "Império Macedônico"],
    correctAnswer: "Império Mongol",
  },
  {
    question: "Por onde o General Aníbal atacou o centro do Imério Romano na segunda guerra púnica?",
    options: ["Ilha da Sicília", "Costa Oeste Italiana", "Alpes Italianos", "Sul da Itália"],
    correctAnswer: "Alpes Italianos",
  },
  {
    question: "Qual o nome completo da firma de auditoria PwC",
    options: ["PraiseWalterCarther", "PriceWaterhouseCoopers", "PartherWilliamsCruz", "PortoWeberCarvalho"],
    correctAnswer: "PriceWaterhouseCoopers",
  },
];

const QuizScreen = ({ navigation }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [score, setScore] = useState(0);

  const handleAnswer = (selectedOption) => {
    if (selectedOption === questions[currentQuestionIndex].correctAnswer) {
      setScore((prevScore) => prevScore + 1);
    }

    // Verifica se existem mais questões
    if (currentQuestionIndex + 1 < questions.length) {
      setCurrentQuestionIndex((prevIndex) => prevIndex + 1);
    } else {
      navigation.navigate('Resultado', { score: score + (selectedOption === questions[currentQuestionIndex].correctAnswer ? 1 : 0), totalQuestions: questions.length });
    }
  };

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.question}>{currentQuestion.question}</Text>
      {currentQuestion.options.map((option, index) => (
        <View key={index} style={styles.buttonContainer}>
          <Button title={option} onPress={() => handleAnswer(option)} />
        </View>
      ))}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  question: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  buttonContainer: {
    marginBottom: 10,
    width: '100%',
  },
});

export default QuizScreen;
