import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

const ResultScreen = ({ route, navigation }) => {
  const { score, totalQuestions } = route.params;

  const handleRetry = () => {
    navigation.replace('Quiz');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Resultado Final</Text>
      <Text style={styles.score}>
        Você acertou {score} de {totalQuestions} questões!
      </Text>
      <Button title="Refazer Quiz" onPress={handleRetry} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
  },
  score: {
    fontSize: 20,
    marginBottom: 20,
  },
});

export default ResultScreen;
