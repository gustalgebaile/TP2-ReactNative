import React from 'react';
import { Text, StyleSheet, View } from 'react-native';

const TaskItem = ({ task }) => {
  return (
    <View style={styles.item}>
      <Text style={styles.text}>{task}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  item: {
    backgroundColor: '#fff',
    padding: 15,
    marginBottom: 10,
    borderRadius: 5,
    elevation: 2,
  },
  text: {
    fontSize: 16,
  },
});

export default TaskItem;
