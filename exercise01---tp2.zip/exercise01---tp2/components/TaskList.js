import React from 'react';
import { View, StyleSheet } from 'react-native';
import TaskItem from './TaskItem';

const TaskList = ({ tasks }) => {
  return (
    <View style={styles.listContainer}>
      {tasks.map((task, index) => (
        <TaskItem key={index} task={task} />
      ))}
    </View>
  );
};

const styles = StyleSheet.create({
  listContainer: {
    flex: 1,
    marginTop: 20,
  },
});

export default TaskList;
