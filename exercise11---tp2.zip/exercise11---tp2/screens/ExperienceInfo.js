import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const ExperienceInfo = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Experiência Profissional</Text>
      <Text> Auditor de Sistemas - PwC 2024-202?</Text>
      <Text> Analsita de Riscos e Controles - PwC 2024-202? </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
});

export default ExperienceInfo;
