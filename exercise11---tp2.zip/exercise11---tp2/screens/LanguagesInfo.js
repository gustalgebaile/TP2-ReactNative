import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const LanguagesInfo = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>Idiomas</Text>
      <Text>Inglês: Fluente</Text>
      <Text>Espanhol: Básico</Text>
      <Text>Português: Nativo</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
});

export default LanguagesInfo;
